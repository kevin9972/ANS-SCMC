% 这个函数是主函数，用于计算相似度矩阵W，输入参数是特征矩阵，标签，邻居数和正则化方法
function W=Label_Propagation(feature_matrix,tag,neighbor_num,regulation) 
    % 计算特征矩阵中每个实例之间的距离
    distance_matrix=calculate_instances(feature_matrix);
    % 计算每个实例的最近邻居
    nearst_neighbor_matrix=calculate_neighbors(distance_matrix,neighbor_num);
    % 优化相似度矩阵W，使其满足正则化条件
    W=optimization_similairty_matrix(feature_matrix,nearst_neighbor_matrix,tag,regulation);
end

% 这个函数是优化相似度矩阵W的函数，使用二次规划的方法，输入参数是特征矩阵，最近邻居矩阵，标签和正则化方法
function W=optimization_similairty_matrix(feature_matrix,nearst_neighbor_matrix,tag,regulation) 
   % 获取特征矩阵的行数
   row_num=size(feature_matrix,1);
   % 初始化权重矩阵W为零矩阵
   W=zeros(1,row_num); 
   % 如果标签为1，表示只有一个实例，那么行数设为1
   if tag==1    
       row_num=1;
   end
   % 对每个实例进行循环
   for i=1:row_num      
       % 获取第i个实例的最近邻居的特征矩阵
       nearst_neighbors=feature_matrix(logical(nearst_neighbor_matrix(i,:)'),:);   
       % 获取最近邻居的个数
       neighbors_num=size(nearst_neighbors,1);
       % 计算G矩阵，表示第i个实例与其最近邻居的差异
       G1=repmat(feature_matrix(i,:),neighbors_num,1)-nearst_neighbors; 
       G2=repmat(feature_matrix(i,:),neighbors_num,1)'-nearst_neighbors';
       % 根据正则化方法，计算G_i矩阵，表示相似度矩阵的约束条件
       if regulation=='regulation2'
         G_i=G1*G2+eye(neighbors_num);
       end
       if regulation=='regulation1'
         G_i=G1*G2;
       end
       % 计算H矩阵，表示二次规划的目标函数
       H=2*G_i;
       % 初始化其他参数
       f=[];
       A=[];
       if isempty(H)
           A;
       end
       
       b=[];
       % 设置等式约束，表示权重之和为1
       Aeq=ones(neighbors_num,1)';
       beq=1;
       % 设置下界约束，表示权重非负
       lb=zeros(neighbors_num,1);
       % 设置上界约束，表示权重不超过1
       ub=[];
       % 设置优化选项，不显示输出
       options=optimset('Display','off');
       % 调用quadprog函数，求解二次规划问题，得到最优的权重向量w和目标函数值fval
       [w,fval]= quadprog(H,f,A,b,Aeq,beq,lb,ub,[],options);
       % 转置w向量
       w=w';
       % 将第i个实例的权重向量赋值给W矩阵的第i行
       W(i,logical(nearst_neighbor_matrix(i,:)))=w;     
   end
end

% 这个函数是计算特征矩阵中每个实例之间的距离的函数，输入参数是特征矩阵，输出参数是距离矩阵
function distance_matrix=calculate_instances(feature_matrix) 
    % 获取特征矩阵的行数和列数
    [row_num,col_num]=size(feature_matrix);  
    % 初始化距离矩阵为零矩阵
    distance_matrix=zeros(row_num,row_num);  
    % 对每个实例进行循环
    for i=1:row_num
        % 计算第i个实例与其他实例的距离
        for j=i+1:row_num
            % 使用欧氏距离公式
            distance_matrix(i,j)=sqrt(sum((feature_matrix(i,:)-feature_matrix(j,:)).^2)); 
            % 距离矩阵是对称的
            distance_matrix(j,i)=distance_matrix(i,j);  
        end
        % 将对角线元素设为列数，表示自身距离最大
        distance_matrix(i,i)=col_num;
    end
end

% 这个函数是计算每个实例的最近邻居的函数，输入参数是距离矩阵和邻居数，输出参数是最近邻居矩阵
function nearst_neighbor_matrix=calculate_neighbors(distance_matrix,neighbor_num)
  % 对距离矩阵的每一行进行升序排序，得到排序后的值sv和索引si
  [sv,si]=sort(distance_matrix,2,'ascend'); 
  % 获取距离矩阵的行数和列数
  [row_num,col_num]=size(distance_matrix);
  % 初始化最近邻居矩阵为零矩阵
  nearst_neighbor_matrix=zeros(row_num,col_num);
  % 获取每个实例的最近邻居的索引
  index=si(:,1:neighbor_num);
  % 对每个实例进行循环
  for i=1:row_num
       % 将最近邻居矩阵的对应位置设为1，表示第i个实例的最近邻居
       nearst_neighbor_matrix(i,index(i,:))=1; 
  end
end

