clc;clear; %清除命令窗口和工作空间中的变量

% 定义邻接矩阵Y，假设有m个微生物和n个疾病
m = 4; % 微生物的数量
n = 3; % 疾病的数量
%Y = zeros(m,n); % 初始化邻接矩阵
a=[1,0,1,0;0,0,0,1;0,1,0,0];
Y = a;
% 根据数据填充邻接矩阵
%for i = 1:size(data,1)
%    Y(data(i,1),data(i,2)) = 1; % 如果微生物和疾病有关联，则对应的元素为1
%end


% 计算微生物高斯交互轮廓核相似度
MG = zeros(n,n); % 初始化相似度矩阵
gamma = 1; % 定义常数gamma，可以根据需要调整
for i = 1:n
    for j = 1:n
        % 计算第i个和第j个微生物的交互轮廓，即邻接矩阵Y的第i行和第j行
        IP_i = Y(i,:);
        IP_j = Y(j,:);
        % 计算第i个和第j个微生物的相似度，使用高斯核函数
        MG(i,j) = gaussianKernel(IP_i,IP_j,gamma);
    end
end

% 计算疾病高斯交互轮廓核相似度
DG = zeros(m,m); % 初始化相似度矩阵
gamma = 1; % 定义常数gamma，可以根据需要调整
for i = 1:m
    for j = 1:m
        % 计算第i个和第j个疾病的交互轮廓，即邻接矩阵Y的第i列和第j列
        IP_i = Y(:,i)';
        IP_j = Y(:,j)';
        % 计算第i个和第j个疾病的相似度，使用高斯核函数
        DG(i,j) = gaussianKernel(IP_i,IP_j,gamma);
    end
end
% 定义高斯核函数
function K = gaussianKernel(X1,X2,sigma)
% X1和X2是输入的数据矩阵，每行是一个样本，sigma是高斯核函数的参数
% 返回的是生成的核矩阵K
m = size(X1,1);
n = size(X2,1);
K = zeros(m,n);
% 计算核矩阵
for i = 1:m
    for j = 1:n
        diff = X1(i,:) - X2(j,:);
        K(i,j) = exp(-diff*diff'/(2*sigma^2));
    end
end
end
