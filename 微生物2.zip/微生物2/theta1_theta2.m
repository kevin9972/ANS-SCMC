function theta1_theta2(y)
b = bar3(y);
set(gca,'XTickLabel',[-1:0.2:1]);
set(gca,'YTickLabel',[-2:-2:-20]);
xlabel('θ3','Fontsize',14);
ylabel('θ2','Fontsize',14);
zlabel('AUC','Fontsize',14);
title('LOOCV','Fontsize',14);

ax = gca;
ax.ZLim=[0.865 0.965];
ax.ZTick = [0.865 0.875 0.885 0.895 0.905 0.915 0.925 0.935 0.945 0.955 0.965];
ax.CLim=[0.865 0.965];
colorbar
c = colorbar;
c.Limits = [0.865 0.965];
%c.TickLabels = {'0.943','0.948','0.953','0.958','0.963','0.968','0.973','0.978','0.983'};
%c.Ticks = [0.943 0.948 0.953 0.958 0.963 0.968 0.973 0.978 0.983];
c.TickLabels = {'0.865','0.875','0.885','0.895','0.905','0.915','0.925','0.935','0.945','0.955','0.965'};
c.Ticks = [0.865 0.875 0.885 0.895 0.905 0.915 0.925 0.935 0.945 0.955 0.965];
for k = 1:length(b)
    zdata = b(k).ZData;
    b(k).CData = zdata;
    b(k).FaceColor = 'interp';
end
%}
end