function [W] = MFSimilarity(X,r1,r2,iter)
%rand('state',123);
 rng('default')
[nd,~]=size(X);
W = rand(nd);
D = diag(sum(W,2));
L = D - W;
for i = 1:iter
    W = inv(r1*eye(size(W,1))+r2*eye(size(W,1)))*(r2*D-r2*L);
    
    L = inv(r2*eye(size(L,1)))*(r2*D-r2*W-X*X');
end
for i=1:nd
for j=1:nd
if sum(X(i,:))==0 && sum(X(j,:))==0 &&i==j
    W(i,j)=1;
end
    
end
end

end



