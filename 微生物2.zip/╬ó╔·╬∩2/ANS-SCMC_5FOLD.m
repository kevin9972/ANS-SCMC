clc;clear; %清除命令窗口和工作空间中的变量
warning('off'); %关闭警告信息
%0.97242
currentFolder = pwd; %获取当前文件夹的路径
MicFea = load('microbe_features.txt'); %加载微生物特征数据292x292，每一行代表一个微生物的特征向量
load interaction.mat; %加载相互作用数据，是一个39x292的二值矩阵，表示39种疾病和292种微生物之间的关联关系
DisFea = load('disease_features.txt'); %加载疾病特征数据39x39，每一行代表一个疾病的特征向量
A = interaction; %将相互作用数据赋值给A
A_ori=A; %备份原始的相互作用数据
n = 1;
m = 1;
%参数部分：
  r1 = 7; %10
 r2 = 4;

  lR = 0.01;%正则化项系数，用于防止过拟合

 lM = 0.1;
 lN = 0.1;


learn_rate = 0.1;%没法改，直接报错

 k = 6;

%beifei 96.9
%  r1 = 10;
%  r2 = 0.1;
% 
%  lR = 0.1;%正则化项系数，用于防止过拟合
% 
%  lM = 1.0;
%  lN = 0.1;
% 
% learn_rate = 0.09;%学习率，用于控制梯度下降的速度
% 
% k = 6;



inter = 500;

y_train=WKNKN( A, DisFea, MicFea, k, 1 ); %使用WKNKN算法计算相互作用的预测评分，WKNKN是一种基于协同过滤的推荐算法，利用疾病和微生物的特征数据来提高预测的准确性

similairty_matrix2=MFSimilarity(y_train',r1,r2,inter);
similairty_matrix1=MFSimilarity(y_train,r1,r2,inter);

% similairty_matrix2=LNS(y_train',0,50,'regulation2'); %使用LNS算法计算微生物之间的相似度矩阵，LNS是一种基于局部邻域的相似度计算方法，可以考虑到微生物之间的相互调节关系   
% similairty_matrix1=LNS(y_train,0,20,'regulation2'); %使用LNS算法计算疾病之间的相似度矩阵，同样考虑到疾病之间的相互调节关系   
  y=A_ori;
F_1_ori=LFSLA(y_train,similairty_matrix1,similairty_matrix2,lR,lM,lN,learn_rate); %使用压缩感知的方法优化预测评分，压缩感知是一种利用稀疏性和低秩性来重构信号的技术，可以减少噪声和冗余信息的影响

%allresult(DisFea,MicFea,interaction,A);

F_1_ori_ori=F_1_ori; %备份优化后的预测评分
index=find(A_ori==1); %找出原始相互作用数据中为1的索引，即已知的微生物疾病关联


auc = zeros(1,100); %初始化一个1*100的零矩阵，用于存储AUC值，AUC是一种评价分类器性能的指标，表示ROC曲线下的面积，越接近1越好
for i = 1:1 %循环100次，每次随机划分训练集和测试集
    i; %显示当前的循环次数
    indices = crossvalind('Kfold', length(index), 5); %使用K折交叉验证法将索引分为5组，每组占20%
    A = A_ori; %恢复原始的相互作用数据
    F_1_ori=F_1_ori_ori; %恢复优化后的预测评分
   
    for cv = 1:5 %循环5次，每次将一组作为测试集，其余四组作为训练集
       cv %显示当前的循环次数
       index_2 = find(cv == indices); %找出当前组的索引
      
       A(index(index_2)) = 0; %将当前组的相互作用数据置为0，表示未知，用于测试

        y_train=WKNKN( A, DisFea, MicFea, k, 1 ); %重新使用WKNKN算法计算相互作用的预测评分，这里的参数5和1表示使用五阶的权重矩阵和一阶的核矩阵

        similairty_matrix2=MFSimilarity(y_train',r1,r2,inter);
        similairty_matrix1=MFSimilarity(y_train,r1,r2,inter);


       % similairty_matrix2=LNS(y_train',0,100,'regulation2'); %重新使用LNS算法计算微生物之间的相似度矩阵    
        %similairty_matrix1=LNS(y_train,0,20,'regulation2'); %重新使用LNS算法计算疾病之间的相似度矩阵    
        F_1=LFSLA(y_train,similairty_matrix1,similairty_matrix2,lR,lM,lN,learn_rate); %重新使用压缩感知的方法优化预测评分
        y1=y;
        y1(index(index_2)) = 0;  

        F_1_ori(index(index_2)) = F_1(index(index_2)); %将当前组的优化后的预测评分替换原来的值
       A = A_ori; %恢复原始的相互作用数据
    end

  
    pre_label_score = F_1_ori(:); %将优化后的预测评分转换为一维向量
    label_y = A_ori(:); %将原始的相互作用数据转换为一维向量
    auc = roc_1(pre_label_score,label_y,'red'); %使用roc_1函数计算预测评分和原始数据之间的AUC值，并用红色显示
end
auc_ave = mean(auc); %计算AUC值的平均值
auc_std = std(auc); %计算AUC值的标准差
a(n,m) = auc;
%m = m+1;
% end
%n=n+1;
%m = 1;
%end