clear;
clc;
warning('off');


currentFolder = pwd;              
addpath(genpath(currentFolder));  

Wdd = load('microbe_features.txt');
 load interaction.mat;
Wrr_v=load('disease_features.txt');
A = interaction;
A_ori=A;


y_train=WKNKN( A, Wrr_v, Wdd, 5, 1 ); 
similairty_matrix2=LNS(y_train',0,50,'regulation2');    

        
similairty_matrix1=LNS(y_train,0,39,'regulation2');    
F_1_ori=BR(y_train,similairty_matrix1,similairty_matrix2,5,4,0.2);

[~,disease]=xlsread(['disease_178.xlsx']);
[~,lncRNA]=xlsread(['lncRNA_115.xlsx']);
%% ���ս��
allresult(lncRNA,disease,A,F_1_ori);  
